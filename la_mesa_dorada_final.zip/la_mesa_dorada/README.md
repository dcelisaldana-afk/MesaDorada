# La Mesa Dorada — App móvil para restaurante

Aplicaciones Móviles · Grupo B191 · Unidades Tecnológicas de Santander (2026)
Integrantes: Juan Camilo Campo Velandia · Dylan Celis Aldana · Fernando Méndez Vásquez

App en **Flutter** (Android e iOS) construida a partir del prototipo interactivo de Figma.
**Versión final 1.0**: cronograma completo (S1–S13) y los 10 requisitos funcionales y 10 no funcionales (ver [`docs/CRONOGRAMA.md`](docs/CRONOGRAMA.md) y [`docs/REQUISITOS.md`](docs/REQUISITOS.md)).

**Acceso de cocina:** Más → *Acceso cocina* · usuario `cocina` · contraseña `Cocina2026` (cámbienla desde el panel). Manual: [`docs/MANUAL_COCINA.md`](docs/MANUAL_COCINA.md).

---

## 1. Requisitos

- Flutter 3.22 o superior (`flutter --version`)
- Android Studio (solo para el SDK de Android y el emulador) o un celular Android con **Depuración USB** activada
- VS Code con las extensiones **Flutter** y **Dart**
- Para iOS: un Mac con Xcode

## 2. Primera vez: abrir y ejecutar

En la terminal de VS Code, dentro de esta carpeta:

```bash
flutter pub get
dart run tool/configurar_plataformas.dart
flutter run
```

El script `configurar_plataformas.dart` genera las carpetas `android/` e `ios/` (con `flutter create`, sin tocar `lib/`) y aplica la configuración que necesitan las notificaciones. Solo hay que ejecutarlo **una vez** (si se ejecuta de nuevo no daña nada).

> **¿Ya tienen su propio proyecto Flutter creado?** Copien `lib/`, `assets/`, `test/`, `tool/` y `docs/` a su proyecto, reemplacen las dependencias y la sección `assets:` del `pubspec.yaml` por las de este, y ejecuten los mismos tres comandos. El nombre del proyecto en `pubspec.yaml` debe ser `la_mesa_dorada` (o cambien las importaciones de `test/widget_test.dart`).

### Instalar en un celular

- **Android:** conecta el celular por USB con la depuración USB activa → `flutter run`. Para generar un instalador: `flutter build apk --release` → el archivo queda en `build/app/outputs/flutter-apk/app-release.apk` y se puede pasar al celular.
- **iOS:** abre `ios/Runner.xcworkspace` en Xcode, elige tu equipo de firma y ejecuta.

### Pruebas

```bash
flutter test
```

## 3. Estructura del proyecto

```
lib/
├── main.dart                     Punto de entrada (inicializa notificaciones)
├── app.dart                      MaterialApp + providers + navegación desde notificaciones
│
├── core/                         Lo que usa toda la app
│   ├── constants/
│   │   ├── app_colors.dart       Paleta de Figma (terracota, crema, verdes…)
│   │   ├── app_strings.dart      Todos los textos fijos
│   │   └── app_config.dart       Slider, usuario inicial de cocina, bloqueo y sesión
│   ├── routes/app_routes.dart    Nombres de rutas y qué pantalla abre cada una
│   ├── theme/app_theme.dart      Tema global
│   └── utils/                    Formato de pesos y fechas, íconos, seguridad (hash) y bloqueo
│
├── data/                         Datos (SQLite, versión 2)
│   ├── database/
│   │   ├── database_helper.dart  Crea la base SQLite y sus tablas
│   │   └── datos_iniciales.dart  Categorías, 40 productos, slides y códigos promocionales
│   ├── models/                   Categoria, Producto, ItemCarrito, Pedido, Usuario…
│   └── repositories/             Consultas a la base (catálogo, pedidos, usuarios)
│
├── providers/                    Estado de la app (paquete provider)
│   ├── catalogo_provider.dart    Categorías y productos con stock
│   ├── carrito_provider.dart     Agregar, quitar, cantidades, código promo, totales
│   ├── pedidos_provider.dart     Realizar pedido, historial y cambios de estado de cocina
│   └── sesion_provider.dart      Sesión de cocina (login, cierre por inactividad)
│
├── services/
│   └── notificacion_service.dart Notificaciones push de cada estado del pedido
│
├── screens/                      Una carpeta por pantalla; sus piezas en widgets/
│   ├── splash/                   1. Inicio (logo, Ingresar, Reséñanos)
│   ├── principal/                Contenedor con la barra de navegación inferior
│   ├── buscar/                   Pestaña Buscar
│   ├── mas/                      Pestaña Más
│   ├── menu/                     2. Menú principal (slider + cuadrícula de categorías)
│   ├── categoria/                3. Menú por categoría (incluye SOLD OUT)
│   ├── detalle_producto/         4. Detalle (ingredientes, cantidad, agregar)
│   ├── carrito/                  5. Carrito (código promo, totales, Realizar Pedido)
│   ├── pedidos/                  Confirmación (turno), Mis pedidos y seguimiento
│   └── cocina/                   MÓDULO DE COCINA: login, panel y formulario de producto
│       ├── tabs/                 Pedidos · Inventario · Productos · Ajustes
│       └── widgets/              Guardia de acceso, tarjeta de pedido, fila de inventario
│
└── widgets/                      Componentes reutilizables (botón carrito, barra superior,
                                  imagen con respaldo, selector de cantidad…)

assets/images/                    Fotos exportadas desde Figma (ver LEEME.md allí)
docs/                             Cronograma, requisitos, base de datos y manual de cocina
test/                             Pruebas unitarias
tool/configurar_plataformas.dart  Script de configuración de Android/iOS
```

### ¿Dónde edito…?

| Quiero cambiar…                            | Archivo |
|--------------------------------------------|---------|
| Colores                                    | `lib/core/constants/app_colors.dart` |
| Textos de botones / títulos                | `lib/core/constants/app_strings.dart` |
| Platos, precios, ingredientes o stock      | `lib/data/database/datos_iniciales.dart` (luego sube `version` en `database_helper.dart` o desinstala la app) |
| Códigos promocionales                      | `codigosIniciales` en `datos_iniciales.dart` |
| Usuario inicial de cocina, bloqueo, sesión | `lib/core/constants/app_config.dart` |
| Stock, disponibilidad o productos (en uso) | Desde la app: panel de cocina |
| Slides del menú                            | `slidesDestacados` en `datos_iniciales.dart` |
| Una pantalla                               | `lib/screens/<pantalla>/` |
| Agregar una pantalla nueva                 | Crear carpeta en `lib/screens/` y registrarla en `lib/core/routes/app_routes.dart` |

## 4. Imágenes

Cada plato y categoría ya tiene su foto (Unsplash, uso libre). Las direcciones están en `lib/data/database/imagenes.dart`.

- Por defecto la app **descarga las fotos de internet** la primera vez (mientras cargan se ve un recuadro de color).
- Para que funcionen **sin internet** y carguen al instante: `dart run tool/descargar_imagenes.dart` (las guarda en `assets/images/`), luego detener la app y `flutter run`.
- Para usar sus propias fotos de Figma: guárdenlas en `assets/images/productos/<id>.jpg` (ver [`assets/images/LEEME.md`](assets/images/LEEME.md)); la foto local siempre tiene prioridad.

## 5. Funcionalidades incluidas

- **Splash** con logo, botón *Ingresar* y *Reséñanos* (las reseñas se guardan en la base de datos).
- **Más**: cómo funciona el autoservicio, activar notificaciones, reseñas y acerca de.
- **Menú principal** con slider automático (cada 5 s, deslizando a la derecha), cuadrícula de 10 categorías en 2 columnas y botón fijo *Carrito (N items)*.
- **Menú por categoría** (una pantalla para las 10): imagen, nombre, descripción, precio en COP y botón **+**. Sin stock → imagen en gris, sello **SOLD OUT** y botón deshabilitado.
- **Detalle de producto**: imagen grande con precio, descripción, chips de ingredientes, contador +/−, botón *Agregar al carrito • $total* que lleva al carrito. Respeta el stock disponible.
- **Barra de navegación inferior** (estilo TikTok): Inicio · Buscar · botón central del Carrito (con contador) · Pedidos · Más.
- **Buscar**: por nombre, descripción o ingrediente, con filtro por categoría.
- **Carrito** (autoservicio en el local, sin envío): cambiar cantidades, eliminar, elegir *Comer aquí* o *Para llevar*, código promocional (`MESA10`, `DORADA20`, `BIENVENIDO`), subtotal y total.
- **Realizar pedido**: se guarda en SQLite, descuenta el stock y muestra el **número de turno** para recoger en la barra.
- **Notificaciones push**: al pedir llega "Pedido recibido"; luego, cada vez que la cocina cambia el estado, llega "En preparación", "¡Listo para recoger!" o "Entregado". Tocar una notificación abre el seguimiento del pedido.
- **Mis pedidos** y **seguimiento** con línea de tiempo del estado real.

### Módulo de cocina (administrador)

- **Inicio de sesión** solo para el personal de cocina. Contraseñas guardadas con hash + sal; bloqueo de 5 minutos tras 5 intentos fallidos; cierre de sesión automático tras 30 minutos sin uso.
- **Pedidos**: llegan al instante en orden de llegada; la cocina los pasa a *En preparación → Listo → Entregado* y el cliente recibe la notificación.
- **Inventario**: editar el stock (− / + o escribiendo la cantidad), marcar cada producto como disponible o no disponible, aviso de stock bajo (5 o menos). Los cambios se ven en tiempo real en el menú de los clientes y el carrito se ajusta solo.
- **Productos**: crear, editar y ocultar/mostrar productos del menú.
- **Ajustes**: cambiar contraseña y cerrar sesión.

La app funciona en un solo dispositivo (cliente y cocina en el mismo celular o tablet del local), con todos los datos en SQLite.

## 6. Problemas frecuentes

| Problema | Solución |
|---|---|
| Olvidé la contraseña de cocina | Desinstala la app (se borra la base de datos) y vuelve a instalarla: el usuario vuelve a ser `cocina` / `Cocina2026`. |
| `Dependency ':flutter_local_notifications' requires core library desugaring` | No se ejecutó `dart run tool/configurar_plataformas.dart`, o el proyecto ya tenía `android/`. Ver la sección 3 de [`docs/CRONOGRAMA.md`](docs/CRONOGRAMA.md#configuración-manual-de-android). |
| Pantalla en negro al abrir la app | Ejecutar de nuevo `dart run tool/configurar_plataformas.dart` (desactiva Impeller en el AndroidManifest) y luego `flutter run`. Para probar rápido: `flutter run --no-enable-impeller`. |
| No llegan notificaciones (Android 13+) | Aceptar el permiso al hacer el primer pedido, o ☰ → *Activar notificaciones*. En algunos Xiaomi/Huawei hay que permitir "Inicio automático". |
| Cambié datos en `datos_iniciales.dart` y no se ven | Subir `version` en `database_helper.dart` o desinstalar la app del celular. |
| Agregué fotos y no aparecen | Detener la app y volver a ejecutar `flutter run`. |
